package com.example.todo;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TodoListFragment extends Fragment {
    private RecyclerView mTodoRecyclerView;
    private TodoAdapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_todo_list, container, false);

        mTodoRecyclerView = (RecyclerView) view.findViewById(R.id.todo_recycler_view);
        mTodoRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUI();

        return view;
    }

    @Override
    public void onResume(){
        super.onResume();
        updateUI();
    }

    private void updateUI(){
        TodoLab todoLab = TodoLab.get(getActivity());
        List<Todo> todos = todoLab.getTasks();

        if (mAdapter == null){
            mAdapter = new TodoAdapter(todos);
            mTodoRecyclerView.setAdapter(mAdapter);
        }else{
            mAdapter.notifyDataSetChanged();
        }

        mAdapter = new TodoAdapter(todos);
        mTodoRecyclerView.setAdapter(mAdapter);
    }

    private class TodoTaskHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private Todo mTodo;
        private TextView mTitleTextView;
        private TextView mDetailTextView;
        private TextView mDateTextView;
        private CheckBox mDoneCheckBox;
        public TodoTaskHolder(View itemView){
            super(itemView);
            itemView.setOnClickListener(this);
            mTitleTextView = (TextView) itemView.findViewById(R.id.list_item_todo_title_textview);
            mDetailTextView = (TextView) itemView.findViewById(R.id.list_item_todo_details_textview);
            mDateTextView = (TextView) itemView.findViewById(R.id.list_todo_item_date_textview);
            mDoneCheckBox = (CheckBox) itemView.findViewById(R.id.list_item_todo_done_checkbox);
        }

        public void bindTodo(Todo todo){
            mTodo = todo;
            mTitleTextView.setText(mTodo.getTitle());
            mDetailTextView.setText(mTodo.getDetails());
            mDateTextView.setText(mTodo.getDate().toString());
            mDoneCheckBox.setChecked(mTodo.isDone());
        }

        @Override
        public void onClick(View v){
            Intent intent = TodoPagerActivity.newIntent(getActivity(), mTodo.getId());
            startActivity(intent);
        }
    }

    private class TodoAdapter extends RecyclerView.Adapter<TodoTaskHolder>{
        private List<Todo> mTodos;
        public TodoAdapter(List<Todo> todos){
            mTodos = todos;
        }

        @NonNull
        @Override
        public TodoTaskHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            View view = layoutInflater.inflate(R.layout.list_item_todo,parent,false);
            return new TodoTaskHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull TodoTaskHolder holder, int position) {
            Todo todo = mTodos.get(position);
            holder.bindTodo(todo);
        }

        @Override
        public int getItemCount() {
            return mTodos.size();
        }
    }

}
