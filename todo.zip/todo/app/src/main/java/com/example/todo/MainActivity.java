package com.example.todo;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;

import java.util.UUID;

public class MainActivity extends SingleFragmentActivity {

    private static final String EXTRA_TODO_ID = "com.example.todo.todo_id";

    @Override
    protected Fragment createFragment() {
        UUID todoId = (UUID) getIntent().getSerializableExtra(EXTRA_TODO_ID);
        return TodoFragment.newInstance(todoId);
    }

    public static Intent newIntent(Context packageContext, UUID todoId){
        Intent intent = new Intent(packageContext, MainActivity.class);
        intent.putExtra(EXTRA_TODO_ID, todoId);
        return intent;
    }
}