package com.example.todo;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TodoLab {
    private static TodoLab sTodoLab;

    private List<Todo> mTasks;

    public static TodoLab get(Context context){
        if (sTodoLab == null){
            sTodoLab = new TodoLab(context);
        }
        return sTodoLab;
    }

    private TodoLab(Context context){
        mTasks = new ArrayList<>();
        for (int i=1;i<=6;i++){
            Todo todo = new Todo();
            todo.setTitle("Task #" + i);
            todo.setDetails("Details on Task #" + i);
            mTasks.add(todo);
        }
    }

    public List<Todo> getTasks(){
        return mTasks;
    }

    public Todo getTask(UUID id){
        for (Todo todo : mTasks){
            if (todo.getId().equals(id)){
                return todo;
            }
        }
        return null;
    }
}
